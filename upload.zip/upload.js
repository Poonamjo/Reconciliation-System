"use strict";

         var myApp = angular.module('myApp', []);

         myApp.directive('fileModel', ['$parse', function ($parse) {
            return {
               restrict: 'A',
               link: function(scope, element, attrs) {
                  var model = $parse(attrs.fileModel);
                  var modelSetter = model.assign;

                  element.bind('change', function() {
                     scope.$apply(function() {
                        modelSetter(scope, element[0].files[0]);
                     });
                  });
               }
            };
         }]);
        /* myApp.service('fileUpload', ['$http','$rootScope',function ($http,$rootScope) {
            var fileUpload=[];
            fileUpload.data=[];
            fileUpload.uploadFileToUrl = function(file, uploadUrl) {
               var fd = new FormData();
               var result;
               fd.append('file', file);

               $http.post(uploadUrl, fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
               })
               .then(function successCallback(response){
                     console.log(response.data);
                     fileUpload.data=response.data;
                  });
                  return fileUpload.data;


            };
            return fileUpload;


         }]);*/
         myApp.controller('myCtrl', function($scope,$rootScope, $http) {
            $scope.uploadFile = function() {
               var file = $scope.myFile;
               console.log('file is ' );
               console.dir(file);
               var uploadUrl = "/fileupload";

               /*$scope.dt=fileUpload.uploadFileToUrl(file, uploadUrl);*/
               var fd = new FormData();
               var result;
               fd.append('file', file);

               $http.post(uploadUrl, fd, {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
               })
               .then(function successCallback(response){
                     console.log(response.data);
                     $rootScope.data=[response.data];
                     $rootScope.a="trial";
                  });

            };

				$rootScope.p="p"
               $rootScope.data = [
  {
    "text":"   column 1= column 1",
    "value":  100.0
  },
  {
    "text":"   column 3= column 2",
    "value":  120.0
  }
];

         });
