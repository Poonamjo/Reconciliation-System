#import modules
import os
import re
from io import StringIO
import pandas as pd # for dataframes
import flask
from flask import Flask, request, render_template
from flask_restful import Resource, Api
from sqlalchemy import create_engine
import json
import openpyxl
from xlutils.copy import copy
import csv
import django
from django.utils import translation
import xlrd
from fuzzywuzzy import fuzz
from flask_jsonpify import jsonpify
from flask_cors import CORS, cross_origin
from flask import jsonify
import xlsxwriter
# db_connect = create_engine('sqlite:///chinook.db')
app = Flask(__name__)
CORS(app)


import requests
import gettext

# api = Api(app)
execution_path = os.getcwd()
path=execution_path + "/" + 'arrays.xlsx'
print(os.path.isfile(path))
if(os.path.isfile(path) is not True):
    workbook = xlsxwriter.Workbook(os.path.join(execution_path, 'arrays.xlsx'))
    worksheet = workbook.add_worksheet()
    workbook.close()
URL_BASE = 'http://localhost:5000/'


dic=[]
@cross_origin()


# def
@app.route('/fileupload', methods=['GET','POST'])



def get_data():
    # get url
    file1 = request.files['file0']
    file2 = request.files['file1']
    fi1=file1.filename
    fi2 = file2.filename

    # dic.append(request.data)
    print(fi1)
    print(fi2)
    file1.save(os.path.join(execution_path, fi1))
    file2.save(os.path.join(execution_path, fi2))
    path1=execution_path+ "/"+fi1
    path2 = execution_path + "/" + fi2

    wb1 = xlrd.open_workbook(path1)
    wb2 = xlrd.open_workbook(path2)
    wb3 = xlrd.open_workbook(path)
    s1 = wb1.sheet_by_index(0)
    s2 = wb2.sheet_by_index(0)
    s3 = wb3.sheet_by_index(0)
    # print(s1.nrows)
    # print(s1.row_values(s1.nrows -1 ))
    # print(s2.row_values(s2.nrows -1 ))
    text=''
    s=1
    i= 1
    j = 1
    k=1
    df = pd.DataFrame()
    # if (dictionary):
    df1 = pd.read_excel(path,index_col=None, header=None)
    print(df1)
    entry=[]
    #----first check from dictionary

    for i in range(s1.ncols):
        for k in range(s3.nrows):
            if (str(s1.cell_value(s, i)) == str(s3.cell_value(k, 0))):
              print(s1.cell_value(s, i))
              entry.append(s1.cell_value(s, i))
              print(s3.cell_value(k, 0))
              for j in range(s2.ncols):

                        if str(s2.cell_value(s, j)) == str(s3.cell_value(k, 1)):
                            df=df.append({'Probability': 100, 'Matches': "   column " + str(i + 1) + " :: " + str(s1.cell_value(s, i)) + " = column " + str(j + 1) + " :: " + str(s2.cell_value(s, j))},ignore_index=True)
                            print(s2.cell_value(s, j))
                            print(s3.cell_value(k, 0))
                        # else:
    s=1
    i=1
    j=1
    for i in range(s1.ncols):
        for j in range(s1.ncols):
            ratio=fuzz.ratio(str(s1.cell_value(s,i)),str(s2.cell_value(s,j)))
            if (type(s1.cell_value(s, i)) is float and ratio==100):
                df = df.append({'Probability': ratio, 'Matches': "   column " + str(i + 1) + " :: " + str(s1.cell_value(s, i)) + " = column " + str(j + 1) + " :: " + str(s2.cell_value(s, j))},ignore_index=True)
                text = text + " " + str(s1.cell_value(s, i))



            if (type(s1.cell_value(s, i)) is str and ratio>10):
                print(entry)
                if (str(s1.cell_value(s, i)) not in entry) :
                 df = df.append({'Probability': ratio, 'Matches': "   column " + str(i + 1) + " :: " + str(s1.cell_value(s, i)) + " = column " + str(j + 1) + " :: " + str(s2.cell_value(s, j))},ignore_index=True)
                 text = text + " " + str(s1.cell_value(s, i)) + " " + str(s2.cell_value(s, j))






    print(df)
    df_list=df.to_dict('records')
    print(df_list)


    # json_data=jsonpify(df_list)
    json_data=json.dumps(df_list)
    print(json_data)
    print(text)
    os.remove(path1)
    os.remove(path2)
    return json_data

@app.route('/data', methods=['GET','POST'])

def data():
    response=request.data
    print(response)
    list=str(response)[2:-1]
    arr = list.split(",")
    # print(list_name)
    wb1 = xlrd.open_workbook(path)

    ws1=wb1.sheet_by_index(0)
    w = openpyxl.load_workbook(path)
    ws = w.get_sheet_by_name('Sheet1')
    row = ws1.nrows +1
    col=1
    print(row)
    print(col)
    arr1=[]
    for x in arr:
        s = re.sub("\s*column [0-9]+ :: ", "", x)
        s = s.split(" =")
        arr1.append(s)
    for x, y in arr1:
        ws.cell(row,col).value= x
        ws.cell(row,col+1).value= y
        row+=1

    # w = copy(wb1)
    w.save(path)
    w.close()

    # return jsonify("list"=list)
    return jsonify(arr)



if __name__ == '__main__':
    app.run(port=5000)